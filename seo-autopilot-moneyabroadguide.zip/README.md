# SEO Autopilot – MoneyAbroadGuide

One-click SEO audit & optimization system.

## Run
- GitHub Actions → Run Full Optimization

## Modes
- audit_only
- safe_autofix
- full_optimization
