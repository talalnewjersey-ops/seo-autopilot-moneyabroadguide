import requests
from bs4 import BeautifulSoup

def crawl(url):
    res = requests.get(url)
    soup = BeautifulSoup(res.text, "html.parser")
    return {
        "title": soup.title.string if soup.title else "",
        "h1": [h.text for h in soup.find_all("h1")]
    }
