def run(data):
    issues = []
    if not data.get("title"):
        issues.append("Missing title")
    if not data.get("h1"):
        issues.append("Missing H1")
    return issues
